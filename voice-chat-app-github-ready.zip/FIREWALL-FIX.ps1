# PowerShell Script to Fix Voice Chat Firewall Issues
# Run this as Administrator

Write-Host "Voice Chat Firewall Fixer" -ForegroundColor Cyan
Write-Host "=========================" -ForegroundColor Cyan

# 1. Allow Node.js (Application Level)
$nodePath = Get-Command node.exe -ErrorAction SilentlyContinue
if ($nodePath) {
    $nodeExe = $nodePath.Source
    Write-Host "Found Node.js at: $nodeExe" -ForegroundColor Green
    
    # Remove existing rules to avoid duplicates
    Remove-NetFirewallRule -DisplayName "Voice Chat - Node.js" -ErrorAction SilentlyContinue

    # Add Allow Rule
    New-NetFirewallRule -DisplayName "Voice Chat - Node.js" `
        -Direction Inbound `
        -Program $nodeExe `
        -Action Allow `
        -Profile Any `
        -Description "Allow Node.js for Voice Chat App"

    Write-Host "✅ Created rule for Node.js application" -ForegroundColor Green
} else {
    Write-Host "⚠️ Node.js not found in PATH. Skipping app-level rule." -ForegroundColor Yellow
}

# 2. Open Port 3001 (Signaling Server)
Remove-NetFirewallRule -DisplayName "Voice Chat - Signaling Port 3001" -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName "Voice Chat - Signaling Port 3001" `
    -Direction Inbound `
    -Protocol TCP `
    -LocalPort 3001 `
    -Action Allow `
    -Profile Any `
    -Description "Allow voice chat signaling"

Write-Host "✅ Opened TCP Port 3001 (Signaling)" -ForegroundColor Green

# 3. Allow UDP Traffic (WebRTC Audio)
# WebRTC uses dynamic UDP ports. It's best to allow the application (Step 1),
# but if strict firewalls are in place, we might need a broad UDP rule or specific range.
# Here we open a wide range often used, but rely on App-level rule primarily.

Remove-NetFirewallRule -DisplayName "Voice Chat - WebRTC UDP" -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName "Voice Chat - WebRTC UDP" `
    -Direction Inbound `
    -Protocol UDP `
    -LocalPort 1024-65535 `
    -Action Allow `
    -Profile Private,Domain `
    -Description "Allow WebRTC Audio Traffic"

Write-Host "✅ Enabled UDP traffic path (Ports 1024-65535) for Private/Domain networks" -ForegroundColor Green

Write-Host "`nDONE! Windows Firewall should now allow voice traffic from other subnets." -ForegroundColor Cyan
Write-Host "Please restart the voice chat server (npm start) for changes to take effect." -ForegroundColor Gray
