# Voice Chat Pro 🎙�?
**Real-time Voice Communication over LAN**

A lightweight, professional voice chat application built with **WebRTC** and **Socket.IO** for seamless local area network communication. Designed for low-latency, privacy, and ease of use within corporate or home networks.

![Status](https://img.shields.io/badge/Status-Active-success) ![Version](https://img.shields.io/badge/Version-1.1.0-blue)

---

## 🚀 Quick Start

### 1. Prerequisites
- **Node.js** (v14+) installed.
- **Microphone** access.

### 2. Run the Server

**Option A: Using Docker (Recommended for NAS/Servers)**
```powershell
docker-compose up -d --build
```
The server will start on **https://localhost:3001** (or your mapped NAS port).

**Option B: Using Node.js**
```powershell
# In the project directory
npm install  # First time only
npm start
```
The server will start on **https://localhost:3001** (and your LAN IP).

### 3. Connect
- **Local:** Open `https://localhost:3001`
- **LAN:** Open `https://[YOUR-PC-IP]:3001` on other devices.
    - *Note: Accept the "Not Secure" warning (self-signed certificate).*

---

## 📚 Documentation

For detailed guides, please refer to **[MANUAL.md](./MANUAL.md)**, which covers:
- **Installation & Deployment**: Setup on new machines.
- **Firewall & Network**: Fixing one-way audio/subnet issues.
- **Mobile Setup**: Connecting phones/tablets.
- **Troubleshooting**: Common errors and solutions.

---

## �?Features

- **Real-time Voice**: Crystal clear audio via WebRTC.
- **Private Rooms**: Create exclusive zones for private conversations.
- **Visual Feedback**: Real-time audio level indicators and "speaking" glow.
- **Echo Cancellation**: Built-in audio processing for clean sound.
- **Wake Lock**: Keeps mobile screens awake during calls.
- **Diagnostics**: Press `Shift+D` to view network connection stats.

---

## 🛠�?Technology Stack

- **Backend**: Node.js, Express, Socket.IO
- **Frontend**: Vanilla JS, WebRTC API
- **Transport**: UDP (Media), TCP/WebSocket (Signaling)

---

## 📜 License
MIT License - Developed by **Open Source Developer**.
