@echo off
cls
echo ============================================================
echo           Voice Chat Pro - HTTPS Server
echo ============================================================
echo.
echo Starting server...
echo.
echo Press Ctrl+C to stop the server
echo ============================================================
echo.
cd /d "%~dp0"
node server.js
pause
