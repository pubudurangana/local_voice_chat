﻿const forge = require('node-forge');
const fs = require('fs');
const path = require('path');

console.log('🔐 Generating SSL certificate using node-forge...\n');

// Generate a key pair
const keys = forge.pki.rsa.generateKeyPair(2048);

// Create a certificate
const cert = forge.pki.createCertificate();
cert.publicKey = keys.publicKey;
cert.serialNumber = '01';
cert.validity.notBefore = new Date();
cert.validity.notAfter = new Date();
cert.validity.notAfter.setFullYear(cert.validity.notBefore.getFullYear() + 5);

const attrs = [
  { name: 'commonName', value: 'localhost' },
  { name: 'countryName', value: 'LK' },
  { name: 'stateOrProvinceName', value: 'Western' },
  { name: 'localityName', value: 'Colombo' },
  { name: 'organizationName', value: 'CEB Voice Chat' }
];

cert.setSubject(attrs);
cert.setIssuer(attrs);

cert.setExtensions([
  {
    name: 'basicConstraints',
    cA: true
  },
  {
    name: 'keyUsage',
    keyCertSign: true,
    digitalSignature: true,
    nonRepudiation: true,
    keyEncipherment: true,
    dataEncipherment: true
  },
  {
    name: 'extKeyUsage',
    serverAuth: true,
    clientAuth: true,
    codeSigning: true,
    emailProtection: true,
    timeStamping: true
  },
  {
    name: 'subjectAltName',
    altNames: [
      { type: 2, value: 'localhost' },
      { type: 7, ip: '127.0.0.1' }
    ]
  }
]);

// Self-sign certificate
cert.sign(keys.privateKey, forge.md.sha256.create());

// Convert to PEM format
const pemCert = forge.pki.certificateToPem(cert);
const pemKey = forge.pki.privateKeyToPem(keys.privateKey);

// Create ssl directory if it doesn't exist
const sslDir = path.join(__dirname, 'ssl');
if (!fs.existsSync(sslDir)) {
  fs.mkdirSync(sslDir);
}

// Write files
fs.writeFileSync(path.join(sslDir, 'cert.pem'), pemCert);
fs.writeFileSync(path.join(sslDir, 'key.pem'), pemKey);

console.log('✅ Certificate written to ssl/cert.pem');
console.log('✅ Private key written to ssl/key.pem');
console.log('\n🎉 SSL certificates generated successfully!');
console.log('📅 Valid for 5 years (until ' + cert.validity.notAfter.toLocaleDateString() + ')');
console.log('🔒 Certificate ready for HTTPS server\n');
