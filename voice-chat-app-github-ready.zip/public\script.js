const socket = io();
const messagesDiv = document.getElementById('messages');
const textInput = document.getElementById('textInput');
const sendBtn = document.getElementById('sendBtn');
const galleryBtn = document.getElementById('galleryBtn');
const cameraBtn = document.getElementById('cameraBtn');
const voiceBtn = document.getElementById('voiceBtn');
const fileBtn = document.getElementById('fileBtn');
const usersList = document.getElementById('usersList');
const userCount = document.getElementById('userCount');
const chatTitle = document.getElementById('chatTitle');
const chatSubtitle = document.getElementById('chatSubtitle');
const profileName = document.getElementById('profileName');
const userAvatar = document.getElementById('userAvatar');
const adminClearBtn = document.getElementById('adminClearBtn');
const adminUsersBtn = document.getElementById('adminUsersBtn');
const adminModal = document.getElementById('adminModal');
const closeAdminModal = document.getElementById('closeAdminModal');
const registeredUsersList = document.getElementById('registeredUsersList');
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const sidebar = document.getElementById('sidebar');
const chatTabs = document.querySelector('.chat-tabs');

const userName = localStorage.getItem('chat_name');
if (!userName) {
  window.location.href = '/login.html';
}

const ADMIN_USERNAME = 'CE (I&C)';
const isAdmin = userName === ADMIN_USERNAME;

let mediaRecorder = null;
let audioChunks = [];
let isRecording = false;
let currentChat = 'main';
let privateChats = {};
let onlineUsers = [];
let selectedUsers = [];
let registeredUsers = [];

const userAgent = navigator.userAgent.toLowerCase();
const isMobile = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(userAgent);
const isAndroid = /android/i.test(userAgent);

profileName.textContent = userName;
userAvatar.textContent = userName.charAt(0).toUpperCase();

if (isAdmin) {
  adminClearBtn.style.display = 'block';
  adminUsersBtn.style.display = 'block';
}

// Socket connection
socket.on('connect', () => {
  console.log('Connected to server');
  socket.emit('login', userName);
  hideSystemMessage('Connecting...');
});

socket.on('disconnect', (reason) => {
  console.log('Disconnected from server:', reason);
  showSystemMessage('Connection lost. Reconnecting...');
});

socket.on('connect_error', (error) => {
  console.error('Connection error:', error);
  showSystemMessage('Connection error. Please check your network.');
});

socket.on('reconnect', (attemptNumber) => {
  console.log('Reconnected after', attemptNumber, 'attempts');
  showSystemMessage('Reconnected!');
  socket.emit('login', userName);
  setTimeout(() => hideSystemMessage('Reconnected!'), 3000);
});

socket.on('reconnect_attempt', (attemptNumber) => {
  console.log('Reconnection attempt', attemptNumber);
});

socket.on('history', (history) => {
  if (currentChat === 'main') {
    messagesDiv.innerHTML = '';
    history.forEach(msg => displayMessage(msg));
    scrollToBottom();
  }
});

socket.on('message', (msg) => {
  if (currentChat === 'main') {
    displayMessage(msg);
    scrollToBottom();
  }
});

socket.on('privateMessage', (data) => {
  const { message, chatId } = data;
  
  if (!privateChats[chatId]) {
    const users = chatId.split(',').filter(u => u !== userName);
    createPrivateChat(chatId, users);
  }
  
  if (currentChat === chatId) {
    displayMessage(message);
    scrollToBottom();
  } else {
    const tab = document.querySelector(`[data-chat="${chatId}"]`);
    if (tab && !tab.classList.contains('active')) {
      tab.style.background = '#7e22ce';
    }
  }
});

socket.on('privateMessageSent', (data) => {
  const { message, chatId } = data;
  if (currentChat === chatId) {
    displayMessage(message);
    scrollToBottom();
  }
});

socket.on('privateChatHistory', (data) => {
  const { chatId, history } = data;
  if (currentChat === chatId) {
    messagesDiv.innerHTML = '';
    history.forEach(msg => displayMessage(msg));
    scrollToBottom();
  }
});

socket.on('onlineUsers', (users) => {
  onlineUsers = users;
  updateUsersList(users);
});

socket.on('userJoined', (username) => {
  console.log(`${username} joined`);
});

socket.on('userLeft', (username) => {
  console.log(`${username} left`);
});

socket.on('chatCleared', () => {
  if (currentChat === 'main') {
    messagesDiv.innerHTML = '';
    showSystemMessage('Chat has been cleared by admin');
  }
});

socket.on('privateChatCleared', (chatId) => {
  if (currentChat === chatId) {
    messagesDiv.innerHTML = '';
    showSystemMessage('Chat has been cleared');
  }
});

socket.on('registeredUsers', (users) => {
  registeredUsers = users;
  displayRegisteredUsers();
});

socket.on('userRemoved', (username) => {
  console.log(`User removed: ${username}`);
});

function displayMessage(msg) {
  const messageEl = document.createElement('div');
  messageEl.className = `message ${msg.name === userName ? 'me' : 'other'}`;
  
  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  
  if (msg.name !== userName) {
    const sender = document.createElement('div');
    sender.className = 'sender';
    sender.textContent = msg.name;
    bubble.appendChild(sender);
  }
  
  if (msg.text) {
    const text = document.createElement('div');
    text.className = 'text';
    text.textContent = msg.text;
    bubble.appendChild(text);
  }
  
  if (msg.image) {
    const img = document.createElement('img');
    img.src = msg.image;
    img.alt = 'Shared image';
    img.loading = 'lazy';
    bubble.appendChild(img);
  }
  
  if (msg.audio) {
    const audioPlayer = createAudioPlayer(msg.audio);
    bubble.appendChild(audioPlayer);
  }
  
  if (msg.file) {
    const docPreview = createDocumentPreview(msg.file);
    bubble.appendChild(docPreview);
  }
  
  const time = document.createElement('div');
  time.className = 'time';
  time.textContent = formatTime(msg.time);
  bubble.appendChild(time);
  
  messageEl.appendChild(bubble);
  messagesDiv.appendChild(messageEl);
}

function createDocumentPreview(file) {
  const container = document.createElement('div');
  container.className = 'document-preview';
  
  const icon = document.createElement('div');
  icon.className = 'doc-icon';
  icon.textContent = getFileIcon(file.name);
  
  const info = document.createElement('div');
  info.className = 'doc-info';
  
  const name = document.createElement('div');
  name.className = 'doc-name';
  name.textContent = file.name;
  name.title = file.name;
  
  const size = document.createElement('div');
  size.className = 'doc-size';
  size.textContent = formatFileSize(file.size);
  
  info.appendChild(name);
  info.appendChild(size);
  
  const download = document.createElement('button');
  download.className = 'doc-download';
  download.textContent = '⬇ Download';
  download.onclick = () => {
    const link = document.createElement('a');
    link.href = file.data;
    link.download = file.name;
    link.click();
  };
  
  container.appendChild(icon);
  container.appendChild(info);
  container.appendChild(download);
  
  return container;
}

function getFileIcon(filename) {
  const ext = filename.split('.').pop().toLowerCase();
  const icons = {
    pdf: '📄', doc: '📝', docx: '📝', xls: '📊', xlsx: '📊',
    ppt: '📊', pptx: '📊', txt: '📃', zip: '📦', rar: '📦'
  };
  return icons[ext] || '📎';
}

function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
}

function createAudioPlayer(audioSrc) {
  const container = document.createElement('div');
  container.className = 'audio-player';
  
  const audio = document.createElement('audio');
  audio.src = audioSrc;
  audio.preload = 'metadata';
  audio.controls = false;
  
  // Add multiple format support
  audio.innerHTML = `<source src="${audioSrc}" type="audio/webm">
                     <source src="${audioSrc}" type="audio/ogg">
                     <source src="${audioSrc}" type="audio/mpeg">
                     <source src="${audioSrc}" type="audio/wav">`;
  
  const playBtn = document.createElement('button');
  playBtn.className = 'audio-play-btn';
  playBtn.innerHTML = '▶️';
  playBtn.type = 'button';
  
  const waveform = document.createElement('div');
  waveform.className = 'audio-waveform';
  
  const progress = document.createElement('div');
  progress.className = 'audio-progress';
  waveform.appendChild(progress);
  
  // Better error handling
  audio.addEventListener('error', (e) => {
    console.error('Audio error:', e, 'Audio src:', audioSrc.substring(0, 50));
    playBtn.innerHTML = '❌';
    playBtn.disabled = true;
    playBtn.title = 'Audio format not supported on this device';
  });
  
  audio.addEventListener('loadedmetadata', () => {
    console.log('Audio loaded, duration:', audio.duration);
  });
  
  playBtn.addEventListener('click', (e) => {
    e.preventDefault();
    if (playBtn.disabled) return;
    
    if (audio.paused) {
      // Pause all other audio
      document.querySelectorAll('audio').forEach(a => {
        if (a !== audio) {
          a.pause();
          a.currentTime = 0;
        }
      });
      document.querySelectorAll('.audio-play-btn').forEach(btn => {
        if (btn !== playBtn) btn.innerHTML = '▶️';
      });
      
      // Play with error handling
      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            console.log('Audio playing');
            playBtn.innerHTML = '⏸️';
          })
          .catch(err => {
            console.error('Play error:', err);
            alert('Cannot play audio. Format may not be supported on your device.');
            playBtn.innerHTML = '❌';
            playBtn.disabled = true;
          });
      }
    } else {
      audio.pause();
      playBtn.innerHTML = '▶️';
    }
  });
  
  audio.addEventListener('timeupdate', () => {
    if (audio.duration) {
      const percent = (audio.currentTime / audio.duration) * 100;
      progress.style.width = percent + '%';
    }
  });
  
  audio.addEventListener('ended', () => {
    playBtn.innerHTML = '▶️';
    progress.style.width = '0%';
    audio.currentTime = 0;
  });
  
  audio.addEventListener('pause', () => {
    playBtn.innerHTML = '▶️';
  });
  
  container.appendChild(playBtn);
  container.appendChild(waveform);
  
  return container;
}

function formatTime(timestamp) {
  const date = new Date(timestamp);
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  return `${hours}:${minutes}`;
}

function scrollToBottom() {
  setTimeout(() => {
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
  }, 100);
}

function showSystemMessage(text) {
  // Remove existing system message with same text
  const existingMsg = Array.from(messagesDiv.children).find(
    el => el.classList.contains('system-message') && el.textContent === text
  );
  if (existingMsg) return;
  
  const messageEl = document.createElement('div');
  messageEl.className = 'system-message';
  messageEl.style.textAlign = 'center';
  messageEl.style.padding = '10px';
  messageEl.style.color = '#8b949e';
  messageEl.style.fontSize = '13px';
  messageEl.textContent = text;
  messagesDiv.appendChild(messageEl);
  scrollToBottom();
}

function hideSystemMessage(text) {
  const messages = messagesDiv.querySelectorAll('.system-message');
  messages.forEach(msg => {
    if (msg.textContent === text) {
      msg.remove();
    }
  });
}

function sendMessage(msgData) {
  const message = {
    name: userName,
    time: Date.now(),
    ...msgData
  };
  
  // Check if socket is connected
  if (!socket.connected) {
    alert('Not connected to server. Please wait...');
    return;
  }
  
  try {
    if (currentChat === 'main') {
      socket.emit('message', message);
    } else {
      const users = currentChat.split(',').filter(u => u !== userName);
      socket.emit('privateMessage', { to: users, message });
    }
    console.log('Message sent successfully');
  } catch (err) {
    console.error('Error sending message:', err);
    alert('Failed to send message. Please try again.');
  }
}

function sendTextMessage() {
  const text = textInput.value.trim();
  if (text) {
    sendMessage({ text });
    textInput.value = '';
    textInput.focus();
  }
}

sendBtn.addEventListener('click', sendTextMessage);
textInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendTextMessage();
  }
});

function updateUsersList(users) {
  userCount.textContent = users.length;
  usersList.innerHTML = '';
  
  users.forEach(user => {
    const userItem = document.createElement('div');
    userItem.className = 'user-item';
    if (user === userName) {
      userItem.classList.add('me');
    }
    
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'user-checkbox';
    checkbox.style.display = 'none';
    checkbox.id = `user-${user}`;
    
    const avatar = document.createElement('div');
    avatar.className = 'user-avatar-small';
    avatar.textContent = user.charAt(0).toUpperCase();
    
    const info = document.createElement('div');
    info.className = 'user-info';
    
    const name = document.createElement('div');
    name.className = 'user-name';
    name.textContent = user;
    
    if (user === ADMIN_USERNAME) {
      const badge = document.createElement('span');
      badge.className = 'user-badge';
      badge.textContent = 'ADMIN';
      name.appendChild(badge);
    }
    
    if (user === userName) {
      const badge = document.createElement('span');
      badge.className = 'user-badge';
      badge.style.background = '#3fb950';
      badge.textContent = 'YOU';
      name.appendChild(badge);
    }
    
    info.appendChild(name);
    userItem.appendChild(checkbox);
    userItem.appendChild(avatar);
    userItem.appendChild(info);
    
    if (user !== userName) {
      userItem.addEventListener('click', (e) => {
        if (selectedUsers.length > 0) {
          toggleUserSelection(user, checkbox);
        } else {
          openPrivateChat([user]);
        }
      });
      
      userItem.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        startMultiSelect(user, checkbox);
      });
      
      userItem.addEventListener('touchstart', handleTouchStart.bind(null, user, checkbox));
      userItem.addEventListener('touchend', handleTouchEnd);
    }
    
    usersList.appendChild(userItem);
  });
}

let touchTimer;
function handleTouchStart(user, checkbox, e) {
  touchTimer = setTimeout(() => {
    startMultiSelect(user, checkbox);
  }, 500);
}

function handleTouchEnd() {
  clearTimeout(touchTimer);
}

function startMultiSelect(user, checkbox) {
  document.querySelectorAll('.user-checkbox').forEach(cb => {
    cb.style.display = 'block';
  });
  
  const actionBar = createMultiSelectActionBar();
  if (!document.querySelector('.multi-select-bar')) {
    document.querySelector('.online-users').prepend(actionBar);
  }
  
  toggleUserSelection(user, checkbox);
}

function toggleUserSelection(user, checkbox) {
  if (selectedUsers.includes(user)) {
    selectedUsers = selectedUsers.filter(u => u !== user);
    checkbox.checked = false;
  } else {
    selectedUsers.push(user);
    checkbox.checked = true;
  }
  
  updateMultiSelectBar();
}

function createMultiSelectActionBar() {
  const bar = document.createElement('div');
  bar.className = 'multi-select-bar';
  bar.style.cssText = 'padding: 10px; background: #161b22; border-radius: 8px; margin-bottom: 10px; display: flex; gap: 8px; align-items: center;';
  
  const count = document.createElement('span');
  count.id = 'selectedCount';
  count.style.cssText = 'flex: 1; color: #e6edf3; font-size: 13px;';
  count.textContent = 'Select users...';
  
  const startBtn = document.createElement('button');
  startBtn.textContent = 'Start Chat';
  startBtn.style.cssText = 'padding: 6px 12px; background: #2a5298; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 12px;';
  startBtn.onclick = () => {
    if (selectedUsers.length > 0) {
      openPrivateChat(selectedUsers);
      cancelMultiSelect();
    }
  };
  
  const cancelBtn = document.createElement('button');
  cancelBtn.textContent = 'Cancel';
  cancelBtn.style.cssText = 'padding: 6px 12px; background: #30363d; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 12px;';
  cancelBtn.onclick = cancelMultiSelect;
  
  bar.appendChild(count);
  bar.appendChild(startBtn);
  bar.appendChild(cancelBtn);
  
  return bar;
}

function updateMultiSelectBar() {
  const countEl = document.getElementById('selectedCount');
  if (countEl) {
    countEl.textContent = `${selectedUsers.length} user(s) selected`;
  }
}

function cancelMultiSelect() {
  selectedUsers = [];
  document.querySelectorAll('.user-checkbox').forEach(cb => {
    cb.style.display = 'none';
    cb.checked = false;
  });
  const bar = document.querySelector('.multi-select-bar');
  if (bar) bar.remove();
}

function createPrivateChat(chatId, users) {
  if (privateChats[chatId]) return;
  
  privateChats[chatId] = { users, messages: [] };
  
  const tab = document.createElement('button');
  tab.className = 'chat-tab private';
  tab.setAttribute('data-chat', chatId);
  
  const icon = document.createElement('span');
  icon.className = 'tab-icon';
  icon.textContent = users.length > 1 ? '👥' : '👤';
  
  const label = document.createElement('span');
  label.className = 'tab-label';
  label.textContent = users.join(', ');
  label.title = users.join(', ');
  
  const actions = document.createElement('span');
  actions.style.cssText = 'display: flex; gap: 4px; align-items: center;';
  
  const clearBtn = document.createElement('button');
  clearBtn.className = 'tab-action-btn';
  clearBtn.textContent = '🗑️';
  clearBtn.title = 'Clear chat';
  clearBtn.onclick = (e) => {
    e.stopPropagation();
    clearPrivateChatConfirm(chatId);
  };
  
  const closeBtn = document.createElement('button');
  closeBtn.className = 'close-tab';
  closeBtn.textContent = '✕';
  closeBtn.onclick = (e) => {
    e.stopPropagation();
    closePrivateChat(chatId);
  };
  
  actions.appendChild(clearBtn);
  actions.appendChild(closeBtn);
  
  tab.appendChild(icon);
  tab.appendChild(label);
  tab.appendChild(actions);
  
  tab.addEventListener('click', () => switchChat(chatId));
  
  chatTabs.appendChild(tab);
}

function openPrivateChat(users) {
  const allUsers = [userName, ...users].sort();
  const chatId = allUsers.join(',');
  
  if (!privateChats[chatId]) {
    createPrivateChat(chatId, users);
    socket.emit('loadPrivateChat', { users: allUsers });
  }
  switchChat(chatId);
  
  if (isMobile) {
    sidebar.classList.remove('active');
  }
}

function closePrivateChat(chatId) {
  delete privateChats[chatId];
  const tab = document.querySelector(`[data-chat="${chatId}"]`);
  if (tab) {
    tab.remove();
  }
  
  if (currentChat === chatId) {
    switchChat('main');
  }
}

function clearPrivateChatConfirm(chatId) {
  if (confirm('Clear this private chat? (History will be backed up on server)')) {
    const users = chatId.split(',');
    socket.emit('clearPrivateChat', { users, requester: userName });
  }
}

function switchChat(chatId) {
  currentChat = chatId;
  
  document.querySelectorAll('.chat-tab').forEach(tab => {
    tab.classList.remove('active');
    tab.style.background = '';
  });
  
  const activeTab = document.querySelector(`[data-chat="${chatId}"]`);
  if (activeTab) {
    activeTab.classList.add('active');
  }
  
  messagesDiv.innerHTML = '';
  
  if (chatId === 'main') {
    chatTitle.textContent = 'Main Chat';
    chatSubtitle.textContent = 'Everyone';
    adminClearBtn.style.display = isAdmin ? 'block' : 'none';
    socket.emit('login', userName);
  } else {
    const users = chatId.split(',').filter(u => u !== userName);
    chatTitle.textContent = users.join(', ');
    chatSubtitle.textContent = `Private Chat (${users.length + 1} members)`;
    adminClearBtn.style.display = 'none';
    
    const allUsers = chatId.split(',');
    socket.emit('loadPrivateChat', { users: allUsers });
  }
  
  if (isMobile) {
    sidebar.classList.remove('active');
  }
}

adminClearBtn.addEventListener('click', () => {
  if (confirm('Clear the main chat? (History will be backed up on server)')) {
    socket.emit('clearChat', userName);
  }
});

adminUsersBtn.addEventListener('click', () => {
  socket.emit('getRegisteredUsers', userName);
  adminModal.style.display = 'flex';
});

closeAdminModal.addEventListener('click', () => {
  adminModal.style.display = 'none';
});

adminModal.addEventListener('click', (e) => {
  if (e.target === adminModal) {
    adminModal.style.display = 'none';
  }
});

function displayRegisteredUsers() {
  registeredUsersList.innerHTML = '';
  
  if (registeredUsers.length === 0) {
    registeredUsersList.innerHTML = '<p style="color: #8b949e; text-align: center; padding: 20px;">No users registered yet</p>';
    return;
  }
  
  registeredUsers.forEach(user => {
    const item = document.createElement('div');
    item.className = 'registered-user-item';
    
    const info = document.createElement('div');
    info.className = 'registered-user-info';
    
    const avatar = document.createElement('div');
    avatar.className = 'registered-user-avatar';
    avatar.textContent = user.charAt(0).toUpperCase();
    
    const nameContainer = document.createElement('div');
    
    const name = document.createElement('div');
    name.className = 'registered-user-name';
    name.textContent = user;
    
    const status = document.createElement('div');
    status.className = 'registered-user-status';
    if (onlineUsers.includes(user)) {
      status.textContent = 'Online';
      status.classList.add('online');
    } else {
      status.textContent = 'Offline';
    }
    
    nameContainer.appendChild(name);
    nameContainer.appendChild(status);
    
    info.appendChild(avatar);
    info.appendChild(nameContainer);
    
    item.appendChild(info);
    
    if (user !== ADMIN_USERNAME) {
      const removeBtn = document.createElement('button');
      removeBtn.className = 'user-remove-btn';
      removeBtn.textContent = 'Remove';
      removeBtn.onclick = () => removeUserConfirm(user);
      item.appendChild(removeBtn);
    }
    
    registeredUsersList.appendChild(item);
  });
}

function removeUserConfirm(username) {
  if (confirm(`Remove user "${username}"? They can still re-join by logging in again.`)) {
    socket.emit('removeUser', { admin: userName, username });
  }
}

mobileMenuBtn.addEventListener('click', () => {
  sidebar.classList.toggle('active');
});

// Click outside sidebar to close on mobile
document.addEventListener('click', (e) => {
  if (isMobile && sidebar.classList.contains('active')) {
    if (!sidebar.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
      sidebar.classList.remove('active');
    }
  }
});

galleryBtn.addEventListener('click', () => {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.style.display = 'none';
  
  input.onchange = (e) => {
    const file = e.target.files[0];
    if (file) handleImageUpload(file);
    document.body.removeChild(input);
  };
  
  document.body.appendChild(input);
  input.click();
});

cameraBtn.addEventListener('click', () => {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.style.display = 'none';
  
  if (isMobile) {
    input.setAttribute('capture', 'environment');
  }
  
  input.onchange = (e) => {
    const file = e.target.files[0];
    if (file) handleImageUpload(file);
    document.body.removeChild(input);
  };
  
  document.body.appendChild(input);
  input.click();
});

fileBtn.addEventListener('click', () => {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.zip,.rar';
  input.style.display = 'none';
  
  input.onchange = (e) => {
    const file = e.target.files[0];
    if (file) {
      console.log('File selected:', file.name, 'Size:', file.size);
      handleFileUpload(file);
    }
    document.body.removeChild(input);
  };
  
  document.body.appendChild(input);
  input.click();
});

async function handleImageUpload(file) {
  if (!file || !file.type.startsWith('image/')) return;
  
  if (isAndroid && file.size === 0) {
    let retries = 0;
    while (file.size === 0 && retries < 15) {
      await new Promise(resolve => setTimeout(resolve, 150));
      retries++;
    }
    
    if (file.size === 0) {
      try {
        const url = URL.createObjectURL(file);
        const response = await fetch(url);
        const blob = await response.blob();
        URL.revokeObjectURL(url);
        
        if (blob.size > 0) {
          file = new File([blob], file.name || 'image.jpg', { type: blob.type || 'image/jpeg' });
        } else {
          alert('Failed to read image.');
          return;
        }
      } catch (err) {
        alert('Failed to process image.');
        return;
      }
    }
  }
  
  if (file.size > 2 * 1024 * 1024) {
    try {
      file = await compressImage(file);
    } catch (err) {
      console.error('Compression failed:', err);
    }
  }
  
  const reader = new FileReader();
  reader.onload = (e) => {
    sendMessage({ image: e.target.result });
  };
  reader.onerror = () => alert('Failed to read image.');
  reader.readAsDataURL(file);
}

function handleFileUpload(file) {
  if (!file) return;
  
  const maxSize = 50 * 1024 * 1024; // 50MB in bytes
  console.log('File size check:', file.size, 'Max:', maxSize);
  
  if (file.size > maxSize) {
    alert(`File too large. Maximum size is 50MB.\nYour file: ${formatFileSize(file.size)}`);
    return;
  }
  
  // Show uploading indicator
  showSystemMessage(`Uploading ${file.name}...`);
  
  const reader = new FileReader();
  reader.onload = (e) => {
    console.log('File read successfully, size:', e.target.result.length);
    sendMessage({
      file: {
        name: file.name,
        data: e.target.result,
        type: file.type,
        size: file.size
      }
    });
  };
  reader.onerror = () => {
    console.error('Failed to read file');
    alert('Failed to read file. Please try again.');
  };
  reader.onprogress = (e) => {
    if (e.lengthComputable) {
      const percent = (e.loaded / e.total * 100).toFixed(0);
      console.log(`Reading file: ${percent}%`);
    }
  };
  reader.readAsDataURL(file);
}

function compressImage(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        const maxSize = 1200;
        
        if (width > height && width > maxSize) {
          height = (height * maxSize) / width;
          width = maxSize;
        } else if (height > maxSize) {
          width = (width * maxSize) / height;
          height = maxSize;
        }
        
        canvas.width = width;
        canvas.height = height;
        
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);
        
        canvas.toBlob(
          (blob) => {
            if (blob) {
              resolve(new File([blob], file.name, { type: 'image/jpeg' }));
            } else {
              reject(new Error('Compression failed'));
            }
          },
          'image/jpeg',
          0.85
        );
      };
      img.onerror = () => reject(new Error('Image load failed'));
      img.src = e.target.result;
    };
    reader.onerror = () => reject(new Error('FileReader failed'));
    reader.readAsDataURL(file);
  });
}

voiceBtn.addEventListener('click', () => {
  if (isMobile) {
    handleMobileVoice();
  } else {
    handleDesktopVoice();
  }
});

function handleMobileVoice() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'audio/*';
  input.style.display = 'none';
  
  if (isAndroid) {
    input.setAttribute('capture', 'microphone');
  }
  
  input.onchange = async (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        sendMessage({ audio: ev.target.result });
      };
      reader.readAsDataURL(file);
    }
    document.body.removeChild(input);
  };
  
  document.body.appendChild(input);
  input.click();
}

async function handleDesktopVoice() {
  if (!isRecording) {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: { 
          echoCancellation: true, 
          noiseSuppression: true,
          sampleRate: 44100
        } 
      });
      
      // Try different audio formats for better compatibility
      let mimeType = 'audio/webm';
      if (!MediaRecorder.isTypeSupported('audio/webm')) {
        if (MediaRecorder.isTypeSupported('audio/ogg')) {
          mimeType = 'audio/ogg';
        } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
          mimeType = 'audio/mp4';
        } else {
          mimeType = ''; // Let browser decide
        }
      }
      
      console.log('Recording with mime type:', mimeType || 'default');
      
      const options = mimeType ? { mimeType } : {};
      mediaRecorder = new MediaRecorder(stream, options);
      audioChunks = [];
      
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunks.push(event.data);
      };
      
      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunks, { type: mimeType || 'audio/webm' });
        console.log('Audio recorded, size:', audioBlob.size, 'type:', audioBlob.type);
        
        const reader = new FileReader();
        reader.onload = (e) => {
          sendMessage({ audio: e.target.result });
        };
        reader.readAsDataURL(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };
      
      mediaRecorder.start();
      isRecording = true;
      voiceBtn.classList.add('recording');
    } catch (err) {
      console.error('Microphone error:', err);
      alert('Could not access microphone. Please check permissions.');
    }
  } else {
    mediaRecorder.stop();
    isRecording = false;
    voiceBtn.classList.remove('recording');
  }
}

console.log('Enhanced Chat App initialized');