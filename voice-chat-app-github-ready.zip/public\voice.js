// Voice Chat Client - Full Version with Visual Speaker Feedback

console.log('[Voice Chat] Loading...');

const socket = io({ secure: true, rejectUnauthorized: false, transports: ['polling'] });

const userName = localStorage.getItem('voice_chat_name');
if (!userName) window.location.href = '/login.html';
console.log('[Voice Chat] Logged in as:', userName);

const usersGrid = document.getElementById('usersGrid');
const roomName = document.getElementById('roomName');
const micBtn = document.getElementById('micBtn');
const volumeSlider = document.getElementById('volumeSlider');
const volumeValue = document.getElementById('volumeValue');
const settingsBtn = document.getElementById('settingsBtn');
const createRoomBtn = document.getElementById('createRoomBtn');
const chatInput = document.getElementById('chatInput');
const sendBtn = document.getElementById('sendBtn');
const chatMessages = document.getElementById('chatMessages');
const leaveRoomBtn = document.getElementById('leaveRoomBtn');
const connectionStatus = document.getElementById('connectionStatus');
const createRoomModal = document.getElementById('createRoomModal');
const settingsModal = document.getElementById('settingsModal');
const closeModal = document.getElementById('closeModal');
const closeSettingsModal = document.getElementById('closeSettingsModal');
const userSelectList = document.getElementById('userSelectList');
const confirmCreateBtn = document.getElementById('confirmCreateBtn');
const cancelBtn = document.getElementById('cancelBtn');
const saveSettingsBtn = document.getElementById('saveSettingsBtn');
const microphoneSelect = document.getElementById('microphoneSelect');
const speakerSelect = document.getElementById('speakerSelect');

// Manual audio unblock UI
let unblockUIBtn = null;

// State
let localStream = null;
let peerConnections = {};
let pendingIceCandidates = {};
let remoteStreams = {};
let currentRoomId = 'main';
let currentRoomName = 'Public Chat';
let roomUsers = [];
let isMuted = false;
let masterVolume = 0.8;
const iceServers = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' }
  ]
};
const audioAnalyzers = {};
// Cleanup all peer connections and audio streams
function cleanupAllConnections() {
  console.log('[Voice Chat] Cleaning up all peer connections...');

  // Close all peer connections
  for (const username in peerConnections) {
    if (peerConnections[username]) {
      try {
        peerConnections[username].close();
        console.log('[Voice Chat] Closed connection to:', username);
      } catch (err) {
        console.warn('[Voice Chat] Error closing connection:', err.message);
      }
    }
  }

  // Clear the peerConnections object
  Object.keys(peerConnections).forEach(key => {
    delete peerConnections[key];
    delete pendingIceCandidates[key];
  });

  // Stop and remove all remote audio streams
  const audioElements = document.querySelectorAll('audio[data-username]');
  audioElements.forEach(audio => {
    try {
      if (audio.srcObject) {
        audio.srcObject.getTracks().forEach(track => track.stop());
        audio.srcObject = null;
      }
      audio.remove();
    } catch (err) {
      console.warn('[Voice Chat] Error removing audio:', err.message);
    }
  });

  // Clear audio analyzers
  for (const username in audioAnalyzers) {
    delete audioAnalyzers[username];
  }

  console.log('[Voice Chat] All connections cleaned up');
}

// Wait for DOM to be ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

async function init() {
  console.log('[Voice Chat] Initializing...');
  updateStatus('connecting', 'Initializing...');
  try {
    await getMicrophone();
    console.log('[Voice Chat] Microphone obtained');
    updateStatus('connected', 'Connected');
    // Keep screen awake during voice chat
    if (typeof window.requestWakeLock === 'function') {
      window.requestWakeLock().catch(err => console.warn('[Wake Lock] Could not activate:', err.message));
    }
  } catch (err) {
    console.warn('[Voice Chat] Microphone not obtained:', err && err.name ? err.name : err);
    updateStatus('warning', 'Listen-only or mic blocked');
  }

  try { await enumerateAndPopulateDevices(); } catch (err) { }
  setupSocketListeners();
  setupUIListeners();

  console.log('[Voice Chat] Joining server...');
  socket.emit('join', { username: userName });
}

async function getMicrophone(deviceId) {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia)
    throw new Error('Browser does not support getUserMedia');
  const audioConstraints = {
    echoCancellation: true,
    noiseSuppression: true,
    autoGainControl: true
  };
  if (deviceId) audioConstraints.deviceId = { exact: deviceId };
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: audioConstraints, video: false });
    if (localStream) localStream.getTracks().forEach(t => t.stop());
    localStream = stream;
    if (localStream.getAudioTracks().length > 0)
      replaceOutgoingTrackForAll(localStream.getAudioTracks()[0]);
    return localStream;
  } catch (err) { throw err; }
}

async function enumerateAndPopulateDevices() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return;
  const devices = await navigator.mediaDevices.enumerateDevices();
  const mics = devices.filter(d => d.kind === 'audioinput');
  const sinks = devices.filter(d => d.kind === 'audiooutput');
  if (microphoneSelect) {
    microphoneSelect.innerHTML = '';
    mics.forEach(m => {
      const opt = document.createElement('option');
      opt.value = m.deviceId;
      opt.text = m.label || `Microphone (${m.deviceId})`;
      microphoneSelect.appendChild(opt);
    });
    microphoneSelect.addEventListener('change', async (e) => {
      try { await getMicrophone(e.target.value); } catch (err) { }
    });
    if (localStream) {
      const track = localStream.getAudioTracks()[0];
      if (track && track.getSettings && track.getSettings().deviceId) {
        microphoneSelect.value = track.getSettings().deviceId;
      }
    }
  }
  if (speakerSelect) {
    speakerSelect.innerHTML = '';
    sinks.forEach(s => {
      const opt = document.createElement('option');
      opt.value = s.deviceId;
      opt.text = s.label || `Speaker (${s.deviceId})`;
      speakerSelect.appendChild(opt);
    });
    speakerSelect.addEventListener('change', (e) => setAllAudioSink(e.target.value));
  }
}

function setupSocketListeners() {
  socket.on('connect', () => updateStatus('connected', 'Connected'));
  socket.on('disconnect', () => { updateStatus('disconnected', 'Disconnected'); cleanupAllConnections(); });
  socket.on('joined', data => {
    currentRoomId = data.roomId;
    currentRoomName = data.roomName;
    roomName.textContent = data.roomName;
    leaveRoomBtn.style.display = data.roomId !== 'main' ? 'block' : 'none';
    updateUsersList(data.users);
  });
  socket.on('roomUsers', data => { if (data.roomId === currentRoomId) updateUsersList(data.users); });
  socket.on('room-invite', data => {
    if (confirm(`${data.invitedBy} invited you to: ${data.roomName}. Join?`))
      socket.emit('join-private-room', { roomId: data.roomId });
  });

  // Handle room creation - creator joins their own room
  socket.on('room-created', data => {
    console.log('[Voice Chat] Private room created:', data.roomName);
    console.log('[Voice Chat] Creator joining room:', data.roomId);
    socket.emit('join-private-room', { roomId: data.roomId });
  });
  socket.on('new-peer', data => {
    const other = data.username;
    // Only create connection if we're the initiator (lower username)
    if (other && other !== userName && userName < other && !peerConnections[other]) {
      console.log('[Voice Chat] New peer - initiating connection to', other);
      createPeerConnection(other, true);
    } else if (other && other !== userName) {
      console.log('[Voice Chat] New peer - waiting for offer from', other);
    }
  });
  socket.on('offer', async data => await handleOffer(data.from, data.offer));
  socket.on('answer', async data => await handleAnswer(data.from, data.answer));
  socket.on('ice-candidate', async data => await handleIceCandidate(data.from, data.candidate));
  socket.on('user-muted', data => updateUserMuteStatus(data.username, data.muted));
  socket.on('chat-message', data => addMessageToChat(data.username, data.text, data.time, data.username === userName, data.isSystem));
}

function setupUIListeners() {
  // Check all required elements exist
  const requiredElements = {
    micBtn, volumeSlider, volumeValue, settingsBtn, createRoomBtn,
    leaveRoomBtn, createRoomModal, settingsModal, closeModal,
    closeSettingsModal, confirmCreateBtn, cancelBtn, saveSettingsBtn,
    chatInput, sendBtn, chatMessages
  };

  for (const [name, element] of Object.entries(requiredElements)) {
    if (!element) {
      console.error(`[Voice Chat] Required element not found: ${name}`);
      return;
    }
  }

  micBtn.addEventListener('click', toggleMicrophone);
  volumeSlider.addEventListener('input', (e) => {
    masterVolume = e.target.value / 100;
    volumeValue.textContent = `${e.target.value}%`;
    updateAllVolumes();
  });
  settingsBtn.addEventListener('click', () => settingsModal.classList.add('active'));
  closeSettingsModal.addEventListener('click', () => settingsModal.classList.remove('active'));
  saveSettingsBtn.addEventListener('click', () => settingsModal.classList.remove('active'));
  createRoomBtn.addEventListener('click', openCreateRoomModal);
  closeModal.addEventListener('click', () => createRoomModal.classList.remove('active'));
  cancelBtn.addEventListener('click', () => createRoomModal.classList.remove('active'));
  confirmCreateBtn.addEventListener('click', createPrivateRoom);
  leaveRoomBtn.addEventListener('click', () => socket.emit('leave-room'));

  // Chat listeners
  const clearChatBtn = document.getElementById('clearChatBtn');
  if (clearChatBtn) {
    clearChatBtn.addEventListener('click', () => {
      if (confirm('Clear chat history?')) {
        chatMessages.innerHTML = '<div class="system-message">Chat cleared</div>';
      }
    });
  }

  sendBtn.addEventListener('click', sendChatMessage);
  chatInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendChatMessage();
  });

  [createRoomModal, settingsModal].forEach(modal => {
    modal.addEventListener('click', (e) => { if (e.target === modal) modal.classList.remove('active'); });
  });
}

function updateUsersList(users) {
  let uniqueUsers = Array.from(new Set(users));
  roomUsers = uniqueUsers.filter(u => u !== userName);
  usersGrid.innerHTML = '';

  // Control wake lock based on whether there are other users
  const hasOtherUsers = roomUsers.length > 0;
  window.shouldKeepScreenAwake = hasOtherUsers; // Track state for visibility changes

  if (hasOtherUsers) {
    // Activate wake lock when users join
    console.log('[Voice Chat] Users present - activating wake lock');
    if (typeof window.requestWakeLock === 'function') {
      window.requestWakeLock().catch(err => console.warn('[Wake Lock] Could not activate:', err.message));
    }
  } else {
    // Release wake lock when no users (allow screen to sleep)
    console.log('[Voice Chat] No users - releasing wake lock');
    if (typeof window.releaseWakeLock === 'function') {
      window.releaseWakeLock();
    }
  }

  if (uniqueUsers.length === 0 || (uniqueUsers.length === 1 && uniqueUsers[0] === userName)) {
    usersGrid.innerHTML = `<div class="empty-state"><div class="empty-icon"></div><div class="empty-text">No one else in the room</div><div class="empty-subtext">Waiting for others to join...</div></div>`;
    cleanupAllConnections();
    return;
  }
  uniqueUsers.forEach(user => usersGrid.appendChild(createUserCard(user)));
  connectToUsersDeterministic(roomUsers);
}

function createUserCard(username) {
  const isMe = username === userName;
  const card = document.createElement('div');
  card.className = 'user-card';
  card.setAttribute('data-username', username);
  card.innerHTML = `
    <div class="user-avatar">${username.charAt(0).toUpperCase()}</div>
    <div class="user-name">${username}${isMe ? ' (You)' : ''}</div>
    <div class="user-status">
      <span class="status-indicator"></span>
      <span class="status-text">Active</span>
    </div>
    <div class="audio-visualizer">
      <div class="audio-bar"></div><div class="audio-bar"></div><div class="audio-bar"></div><div class="audio-bar"></div><div class="audio-bar"></div>
    </div>
    ${!isMe ? `<div class="user-volume"><span></span><input type="range" class="user-volume-slider" min="0" max="100" value="100" data-username="${username}"><span class="user-volume-value">100%</span></div>` : ''}
  `;
  if (!isMe) {
    const slider = card.querySelector('.user-volume-slider');
    const valueSpan = card.querySelector('.user-volume-value');
    slider.addEventListener('input', (e) => { setUserVolume(username, e.target.value / 100); valueSpan.textContent = `${e.target.value}%`; });
  }
  return card;
}

function connectToUsersDeterministic(users) {
  // Close connections to users no longer in room
  Object.keys(peerConnections).forEach(username => {
    if (!users.includes(username)) closePeerConnection(username);
  });

  // Only connect to users whose username is greater (avoids both sides connecting)
  users.forEach(other => {
    if (other !== userName && userName < other && !peerConnections[other]) {
      console.log('[Voice Chat] Deterministic - initiating connection to', other);
      createPeerConnection(other, true);
    }
  });
}

async function createPeerConnection(remoteUser, isInitiator = false) {
  console.log(`[PC] Creating peer connection with ${remoteUser}`);
  if (peerConnections[remoteUser]) return;
  const pc = new RTCPeerConnection(iceServers);
  peerConnections[remoteUser] = pc;
  pc.makingOffer = false;
  pc.isPolite = userName < remoteUser;
  pc.onnegotiationneeded = async () => {
    if (!isInitiator) return; // Only initiator creates offers
    try {
      pc.makingOffer = true;
      if (pc.signalingState !== 'stable') return;
      let offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      socket.emit('offer', { to: remoteUser, from: userName, offer: pc.localDescription });
    } catch (err) { console.error('negotiationneeded error', err); }
    finally { pc.makingOffer = false; }
  };
  // Add local track or recvonly transceiver
  if (localStream) {
    localStream.getTracks().forEach(track => {
      try { pc.addTrack(track, localStream); } catch (e) { }
    });
  } else {
    try { pc.addTransceiver('audio', { direction: 'recvonly' }); } catch (_) { }
  }
  pc.ontrack = (event) => handleRemoteStream(remoteUser, event.streams[0]);
  pc.onicecandidate = (event) => {
    if (event.candidate) socket.emit('ice-candidate', { to: remoteUser, from: userName, candidate: event.candidate });
  };
  pc.onconnectionstatechange = () => {
    console.log(`[PC] ${remoteUser} connection state: ${pc.connectionState}`);
    updateDebugInfo(); // Force update
    if (pc.connectionState === 'failed' || pc.connectionState === 'disconnected')
      closePeerConnection(remoteUser);
  };
  pc.oniceconnectionstatechange = () => {
    console.log(`[PC] ${remoteUser} ICE state: ${pc.iceConnectionState}`);
    updateDebugInfo();
  };
}

async function handleOffer(remoteUser, offer) {
  let pc = peerConnections[remoteUser];
  if (!pc) { await createPeerConnection(remoteUser); pc = peerConnections[remoteUser]; }
  const offerCollision = pc.makingOffer || pc.signalingState !== 'stable';

  // Ignore offer if we're impolite and there's a collision
  if (offerCollision && !pc.isPolite) {
    console.log('[PC] Ignoring offer from', remoteUser, '- impolite peer');
    return;
  }

  try {
    // Only rollback if there's a collision AND we're polite
    if (offerCollision && pc.isPolite) {
      // Only rollback if we're not already in stable state
      if (pc.signalingState !== 'stable') {
        await pc.setLocalDescription({ type: 'rollback' });
      }
    }
    await pc.setRemoteDescription(new RTCSessionDescription(offer));
    // Process any pending ICE candidates
    if (pendingIceCandidates[remoteUser]) {
      for (const candidate of pendingIceCandidates[remoteUser]) {
        try {
          await pc.addIceCandidate(new RTCIceCandidate(candidate));
        } catch (err) {
          console.warn('Failed to add queued ICE candidate', err);
        }
      }
      delete pendingIceCandidates[remoteUser];
    }
    if (localStream) {
      localStream.getTracks().forEach(track => { try { pc.addTrack(track, localStream); } catch { } });
    }
    let answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    socket.emit('answer', { to: remoteUser, from: userName, answer: pc.localDescription });
  } catch (err) { console.error('handleOffer err', err); }
}

async function handleAnswer(remoteUser, answer) {
  let pc = peerConnections[remoteUser];
  if (!pc) return;
  if (pc.signalingState !== 'have-local-offer') return;
  try {
    await pc.setRemoteDescription(new RTCSessionDescription(answer));
    // Process any pending ICE candidates
    if (pendingIceCandidates[remoteUser]) {
      for (const candidate of pendingIceCandidates[remoteUser]) {
        try {
          await pc.addIceCandidate(new RTCIceCandidate(candidate));
        } catch (err) {
          console.warn('Failed to add queued ICE candidate', err);
        }
      }
      delete pendingIceCandidates[remoteUser];
    }
  } catch (err) { console.error('Failed to set answer', err); }
}

async function handleIceCandidate(remoteUser, candidate) {
  let pc = peerConnections[remoteUser];
  if (!pc) return;

  // Queue ICE candidates if remote description is not set yet
  if (!pc.remoteDescription || !pc.remoteDescription.type) {
    if (!pendingIceCandidates[remoteUser]) {
      pendingIceCandidates[remoteUser] = [];
    }
    pendingIceCandidates[remoteUser].push(candidate);
    return;
  }

  try {
    await pc.addIceCandidate(new RTCIceCandidate(candidate));
  } catch (err) {
    console.warn('addIceCandidate failed', err);
  }
}

function handleRemoteStream(remoteUser, stream) {
  if (!stream) return;
  remoteStreams[remoteUser] = stream;
  let audio = document.querySelector(`audio[data-username="${remoteUser}"]`);
  if (!audio) {
    audio = document.createElement('audio');
    audio.setAttribute('data-username', remoteUser);
    audio.autoplay = true;
    audio.playsInline = true;
    audio.volume = masterVolume;
    document.body.appendChild(audio);
  } else { audio.pause(); }
  audio.srcObject = stream;
  const playPromise = audio.play();
  if (playPromise !== undefined) {
    playPromise.catch(err => {
      console.warn('Audio play() rejected for', remoteUser, err);
      maybeShowUnblockAudioUI();
    });
  }
  // Visual speaker detection for this user
  analyzeAudioLevel(remoteUser, stream);
}

// -- AUDIO ANALYZER and VISUALS --

function analyzeAudioLevel(username, stream) {
  // Clean up previous analyzer if any
  if (audioAnalyzers[username] && audioAnalyzers[username].audioContext) {
    try {
      audioAnalyzers[username].audioContext.close();
    } catch (_) { }
    delete audioAnalyzers[username];
  }

  try {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const analyser = audioContext.createAnalyser();
    const source = audioContext.createMediaStreamSource(stream);
    source.connect(analyser);
    analyser.fftSize = 256;
    const dataArray = new Uint8Array(analyser.frequencyBinCount);

    let running = true;
    audioAnalyzers[username] = { audioContext, analyser, running };

    function analyze() {
      if (!audioAnalyzers[username] || !audioAnalyzers[username].running) return;
      analyser.getByteFrequencyData(dataArray);
      const average = dataArray.reduce((a, b) => a + b, 0) / dataArray.length;
      // Show green edge + animated bars only for REMOTE users
      if (username !== userName) updateAudioBars(username, average);
      requestAnimationFrame(analyze);
    }

    analyze();
  } catch (err) {
    console.warn('Audio analysis failed', err);
  }
}

// Cleanup on disconnect
function closePeerConnection(username) {
  if (peerConnections[username]) { try { peerConnections[username].close(); } catch (_) { } delete peerConnections[username]; }
  if (remoteStreams[username]) delete remoteStreams[username];
  // Clean up analyzer
  if (audioAnalyzers[username]) {
    audioAnalyzers[username].running = false;
    if (audioAnalyzers[username].audioContext) {
      try { audioAnalyzers[username].audioContext.close(); } catch (_) { }
    }
    delete audioAnalyzers[username];
  }
  const audio = document.querySelector(`audio[data-username="${username}"]`);
  if (audio) { audio.srcObject = null; audio.remove(); }
  const card = document.querySelector(`[data-username="${username}"]`);
  if (card) card.classList.remove('speaking');
  if (card) card.querySelectorAll('.audio-bar').forEach(bar => bar.style.height = '10px');
  if (card) card.remove();
}

// Animated audio bars and speaking (glow) effect
function updateAudioBars(username, level) {
  const card = document.querySelector(`[data-username="${username}"]`);
  if (!card) return;

  // Glow
  const isSpeaking = level > 15;
  card.classList.toggle('speaking', isSpeaking);

  // Animate audio bars (simulate mid-range amplitude)
  const bars = card.querySelectorAll('.audio-bar');
  if (bars.length) {
    bars.forEach((bar, i) => {
      let base = 10;
      let variable = Math.max(base, Math.min(25, base + level / 3 + Math.random() * 8 - 4));
      bar.style.height = isSpeaking ? `${variable}px` : `${base}px`;
      bar.style.background = isSpeaking ? "#3fb950" : "#30363d";
    });
  }
}

// -- Other helpers --

function setUserVolume(username, volume) {
  const audio = document.querySelector(`audio[data-username="${username}"]`);
  if (audio) audio.volume = volume * masterVolume;
}
function updateAllVolumes() {
  document.querySelectorAll('audio[data-username]').forEach(audio => {
    const username = audio.getAttribute('data-username');
    const slider = document.querySelector(`.user-volume-slider[data-username="${username}"]`);
    const userVolume = slider ? slider.value / 100 : 1;
    audio.volume = userVolume * masterVolume;
  });
}
function toggleMicrophone() {
  if (!localStream) { alert('No microphone available. You are in listen-only mode.'); return; }
  isMuted = !isMuted;
  localStream.getAudioTracks().forEach(track => (track.enabled = !isMuted));
  micBtn.classList.toggle('muted', isMuted);
  const statusEl = micBtn.querySelector('.status');
  if (statusEl) statusEl.textContent = isMuted ? 'MUTED' : 'ON';
  socket.emit('mute-status', { muted: isMuted });
}
function updateUserMuteStatus(username, muted) {
  const card = document.querySelector(`[data-username="${username}"]`);
  if (card) {
    const indicator = card.querySelector('.status-indicator');
    const statusText = card.querySelector('.status-text');
    if (muted) { indicator.classList.add('muted'); statusText.textContent = 'Muted'; }
    else { indicator.classList.remove('muted'); statusText.textContent = 'Active'; }
  }
}
function setSinkIfSupported(audioEl, sinkId) {
  if (!audioEl || !sinkId) return;
  if (typeof audioEl.setSinkId !== 'function') return;
  audioEl.setSinkId(sinkId).catch(() => { });
}
function setAllAudioSink(sinkId) {
  document.querySelectorAll('audio[data-username]').forEach(audio => setSinkIfSupported(audio, sinkId));
}
window.addEventListener('beforeunload', () => {
  cleanupAllConnections();
  if (localStream) localStream.getTracks().forEach(t => t.stop());
});

function replaceOutgoingTrackForAll(track) {
  for (const username in peerConnections) {
    const pc = peerConnections[username];
    if (pc) {
      const sender = pc.getSenders().find(s => s.track && s.track.kind === 'audio');
      if (sender) {
        sender.replaceTrack(track).catch(err => console.warn('replaceTrack failed', err));
      }
    }
  }
}

// Audio unblock UI, mobile autoplay fix
function maybeShowUnblockAudioUI() {
  if (unblockUIBtn) return;
  unblockUIBtn = document.createElement('button');
  unblockUIBtn.style = "position:fixed;top:30px;right:30px;z-index:999;background:#d44;color:white;font-size:20px;padding:16px;border:none;border-radius:10px;box-shadow:0 4px 16px #0004";
  unblockUIBtn.textContent = " Click to Enable All Audio";
  unblockUIBtn.onclick = () => {
    document.querySelectorAll('audio[data-username]').forEach(audio => {
      try { audio.play(); } catch { }
    });
    unblockUIBtn.remove();
    unblockUIBtn = null;
  };
  document.body.appendChild(unblockUIBtn);
}

// Connection status
function updateStatus(status, text) {
  const dot = connectionStatus.querySelector('.status-dot');
  const statusText = connectionStatus.querySelector('.status-text');
  dot.className = 'status-dot';
  if (status === 'connected') dot.classList.add('connected');
  else if (status === 'warning') dot.classList.add('warning');
  statusText.textContent = text;
}

// Private room modal logic
function openCreateRoomModal() {
  userSelectList.innerHTML = '';
  if (roomUsers.length === 0) {
    userSelectList.innerHTML = '<p style="color: #8b949e; text-align: center; padding: 20px;">No other users available</p>';
    createRoomModal.classList.add('active');
    return;
  }
  roomUsers.forEach(user => {
    const item = document.createElement('div');
    item.className = 'user-select-item';
    item.innerHTML = `<input type="checkbox" class="user-select-checkbox" value="${user}"><div class="user-select-avatar">${user.charAt(0).toUpperCase()}</div><div class="user-select-name">${user}</div>`;
    item.addEventListener('click', function (e) {
      if (e.target.type !== 'checkbox') {
        const checkbox = this.querySelector('.user-select-checkbox');
        checkbox.checked = !checkbox.checked;
      }
      this.classList.toggle('selected', this.querySelector('.user-select-checkbox').checked);
    });
    userSelectList.appendChild(item);
  });
  createRoomModal.classList.add('active');
}
function createPrivateRoom() {
  const checkboxes = userSelectList.querySelectorAll('.user-select-checkbox:checked');
  const selectedUsers = Array.from(checkboxes).map(cb => cb.value);
  if (selectedUsers.length === 0) { alert('Please select at least one user'); return; }
  socket.emit('create-private-room', { participants: selectedUsers });
  createRoomModal.classList.remove('active');
}

// -- Diagnostics & Debugging --

const debugPanel = document.createElement('div');
debugPanel.id = 'debugPanel';
debugPanel.style.cssText = `
  position: fixed;
  bottom: 10px;
  right: 10px;
  width: 300px;
  background: rgba(0,0,0,0.8);
  color: #0f0;
  font-family: monospace;
  font-size: 11px;
  padding: 10px;
  border-radius: 5px;
  display: none; 
  user-select: none;
  z-index: 9999;
  pointer-events: none;
`;
document.body.appendChild(debugPanel);

// Toggle debug with 'D' key (Shift+D)
window.addEventListener('keydown', (e) => {
  if (e.key === 'D' && e.shiftKey) {
    debugPanel.style.display = debugPanel.style.display === 'none' ? 'block' : 'none';
  }
});

function updateDebugInfo() {
  if (debugPanel.style.display === 'none') return;

  let html = `<div><strong>[DEBUG Diagnostics] (Shift+D to hide)</strong></div>`;
  html += `<div>My ID: ${socket.id}</div>`;
  html += `<div>Signal Status: ${socket.connected ? 'OK' : 'FAIL'}</div>`;

  const peerCount = Object.keys(peerConnections).length;
  html += `<div>Peers: ${peerCount}</div>`;

  Object.keys(peerConnections).forEach(username => {
    const pc = peerConnections[username];
    const state = pc.connectionState;
    const iceState = pc.iceConnectionState;
    html += `<div style="margin-top:5px; border-top:1px solid #444">
      Peer: <strong>${username}</strong><br>
      State: <span style="color:${state === 'connected' ? 'lime' : 'orange'}">${state}</span><br>
      ICE: ${iceState}<br>
    </div>`;

    // Attempt to get stats
    pc.getStats().then(stats => {
      stats.forEach(report => {
        if (report.type === 'inbound-rtp' && report.kind === 'audio') {
          const bytes = report.bytesReceived || 0;
          const kbits = Math.round(bytes * 8 / 1000);
          const el = document.getElementById(`stats-${username}`);
          if (el) el.innerHTML = `RX: ${kbits} kb`;

          if (bytes === 0 && (state === 'connected' || iceState === 'connected')) {
            // Warn about potential firewall issue
            const warningEl = document.getElementById(`warn-${username}`);
            if (warningEl) warningEl.style.display = 'block';
          }
        }
      });
    });

    html += `<div id="stats-${username}">RX: -</div>`;
    html += `<div id="warn-${username}" style="color:red;display:none">⚠️ No Audio Data (Check Firewall)</div>`;
  });

  debugPanel.innerHTML = html;
}

// Update debug info loop
setInterval(updateDebugInfo, 2000); // Check every 2s

console.log('[Voice Chat] Diagnostics module loaded. Press Shift+D to view.');
console.log('[Voice Chat] Client ready');

// -- Chat Functions --

function sendChatMessage() {
  const text = chatInput.value.trim();
  if (!text) return;

  // Optimistic UI update (optional, but socket broadcast is fast enough locally)
  // socket.emit wil trigger broadcast which comes back to us

  socket.emit('chat-message', { text });
  chatInput.value = '';
  chatInput.focus();
}

function addMessageToChat(username, text, time, isSelf, isSystem) {
  const msgDiv = document.createElement('div');

  if (isSystem) {
    msgDiv.className = 'system-message';
    msgDiv.textContent = text;
  } else {
    msgDiv.className = `message ${isSelf ? 'self' : 'other'}`;

    // Header for others
    const header = !isSelf ?
      `<div class="message-header"><span>${username}</span><span>${time}</span></div>` : '';

    // Footer (time) for self
    const footer = isSelf ?
      `<div class="message-header" style="justify-content: flex-end; margin-top: 2px;"><span>${time}</span></div>` : '';

    msgDiv.innerHTML = `
      ${header}
      <div class="message-bubble">${escapeHtml(text)}</div>
      ${footer}
    `;
  }

  chatMessages.appendChild(msgDiv);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}




















