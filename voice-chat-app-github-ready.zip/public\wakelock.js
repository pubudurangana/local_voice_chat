// Wake Lock API - Keeps phone screen awake during voice chat
// Enhanced with multiple fallback methods for Samsung and other devices
console.log('[Wake Lock] Module loaded');

let wakeLock = null;
let wakeLockIndicator = null;
let videoElement = null;
let audioElement = null;
let wakeLockMethod = null; // Track which method is active

// Create visual indicator
function createWakeLockIndicator() {
    wakeLockIndicator = document.createElement('div');
    wakeLockIndicator.className = 'wake-lock-indicator';
    wakeLockIndicator.innerHTML = 'Screen Awake';
    wakeLockIndicator.style.display = 'none';
    document.body.appendChild(wakeLockIndicator);
}

// Show/hide indicator
function updateWakeLockIndicator(active, method = '') {
    if (!wakeLockIndicator) {
        createWakeLockIndicator();
    }
    
    if (active) {
        wakeLockIndicator.classList.remove('inactive');
        wakeLockIndicator.innerHTML = `Screen Awake${method ? ' (' + method + ')' : ''}`;
        wakeLockIndicator.style.display = 'flex';
    } else {
        wakeLockIndicator.classList.add('inactive');
        wakeLockIndicator.innerHTML = 'Screen May Sleep';
    }
}

// Method 1: Native Wake Lock API
async function requestNativeWakeLock() {
    try {
        if ('wakeLock' in navigator) {
            wakeLock = await navigator.wakeLock.request('screen');
            wakeLockMethod = 'native';
            console.log('[Wake Lock] Native API activated');
            updateWakeLockIndicator(true, 'API');
            
            wakeLock.addEventListener('release', () => {
                console.log('[Wake Lock] Native API released');
                updateWakeLockIndicator(false);
            });
            
            return true;
        }
        return false;
    } catch (err) {
        console.warn('[Wake Lock] Native API failed:', err.message);
        return false;
    }
}

// Method 2: Video fallback (works on most devices)
function setupVideoWakeLock() {
    try {
        console.log('[Wake Lock] Using video fallback method');
        
        // Remove existing video if any
        if (videoElement) {
            videoElement.pause();
            videoElement.srcObject = null;
            videoElement.remove();
        }
        
        videoElement = document.createElement('video');
        videoElement.setAttribute('playsinline', '');
        videoElement.setAttribute('muted', '');
        videoElement.setAttribute('loop', '');
        videoElement.style.position = 'fixed';
        videoElement.style.bottom = '0';
        videoElement.style.right = '0';
        videoElement.style.opacity = '0.01';
        videoElement.style.width = '1px';
        videoElement.style.height = '1px';
        videoElement.style.pointerEvents = 'none';
        videoElement.style.zIndex = '-1';
        
        const canvas = document.createElement('canvas');
        canvas.width = 1;
        canvas.height = 1;
        const ctx = canvas.getContext('2d');
        
        let frame = 0;
        const animationInterval = setInterval(() => {
            if (!videoElement || !videoElement.parentNode) {
                clearInterval(animationInterval);
                return;
            }
            ctx.fillStyle = frame % 2 === 0 ? '#000000' : '#000001';
            ctx.fillRect(0, 0, 1, 1);
            frame++;
        }, 1000);
        
        const stream = canvas.captureStream(1);
        videoElement.srcObject = stream;
        videoElement.muted = true;
        
        document.body.appendChild(videoElement);
        
        return videoElement.play()
            .then(() => {
                wakeLockMethod = 'video';
                console.log('[Wake Lock] Video method activated');
                updateWakeLockIndicator(true, 'Video');
                return true;
            })
            .catch(err => {
                console.warn('[Wake Lock] Video method failed:', err);
                return false;
            });
    } catch (err) {
        console.warn('[Wake Lock] Video setup failed:', err);
        return Promise.resolve(false);
    }
}

// Method 3: Silent audio fallback (for Samsung and other stubborn devices)
function setupAudioWakeLock() {
    try {
        console.log('[Wake Lock] Using silent audio fallback method');
        
        // Remove existing audio if any
        if (audioElement) {
            audioElement.pause();
            audioElement.src = '';
            audioElement.remove();
        }
        
        audioElement = document.createElement('audio');
        audioElement.setAttribute('loop', '');
        audioElement.setAttribute('preload', 'auto');
        audioElement.style.position = 'fixed';
        audioElement.style.bottom = '0';
        audioElement.style.right = '0';
        audioElement.style.opacity = '0';
        audioElement.style.width = '1px';
        audioElement.style.height = '1px';
        audioElement.style.pointerEvents = 'none';
        audioElement.style.zIndex = '-1';
        audioElement.volume = 0.01; // Very low volume
        
        // Create silent audio using Web Audio API
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.frequency.value = 20; // Very low frequency (barely audible)
        gainNode.gain.value = 0.01; // Very low volume
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        const dest = audioContext.createMediaStreamDestination();
        gainNode.connect(dest);
        
        audioElement.srcObject = dest.stream;
        oscillator.start();
        
        document.body.appendChild(audioElement);
        
        return audioElement.play()
            .then(() => {
                wakeLockMethod = 'audio';
                console.log('[Wake Lock] Audio method activated');
                updateWakeLockIndicator(true, 'Audio');
                return true;
            })
            .catch(err => {
                console.warn('[Wake Lock] Audio method failed:', err);
                audioContext.close();
                return false;
            });
    } catch (err) {
        console.warn('[Wake Lock] Audio setup failed:', err);
        return Promise.resolve(false);
    }
}

// Main request function - tries all methods in order
async function requestWakeLock() {
    try {
        // Try native API first
        const nativeSuccess = await requestNativeWakeLock();
        if (nativeSuccess) return true;
        
        // Try video fallback
        const videoSuccess = await setupVideoWakeLock();
        if (videoSuccess) return true;
        
        // Try audio fallback (best for Samsung devices)
        const audioSuccess = await setupAudioWakeLock();
        if (audioSuccess) return true;
        
        console.warn('[Wake Lock] All methods failed');
        updateWakeLockIndicator(false);
        return false;
        
    } catch (err) {
        console.error('[Wake Lock] Request failed:', err.message);
        updateWakeLockIndicator(false);
        return false;
    }
}

// Release wake lock
async function releaseWakeLock() {
    console.log('[Wake Lock] Releasing wake lock, method:', wakeLockMethod);
    
    // Release native wake lock
    if (wakeLock !== null) {
        try {
            await wakeLock.release();
            wakeLock = null;
        } catch (err) {
            console.error('[Wake Lock] Failed to release native:', err);
        }
    }
    
    // Stop video
    if (videoElement) {
        try {
            videoElement.pause();
            if (videoElement.srcObject) {
                videoElement.srcObject.getTracks().forEach(track => track.stop());
                videoElement.srcObject = null;
            }
            videoElement.remove();
            videoElement = null;
        } catch (err) {
            console.error('[Wake Lock] Failed to stop video:', err);
        }
    }
    
    // Stop audio
    if (audioElement) {
        try {
            audioElement.pause();
            if (audioElement.srcObject) {
                audioElement.srcObject.getTracks().forEach(track => track.stop());
                audioElement.srcObject = null;
            }
            audioElement.remove();
            audioElement = null;
        } catch (err) {
            console.error('[Wake Lock] Failed to stop audio:', err);
        }
    }
    
    wakeLockMethod = null;
    console.log('[Wake Lock] Released');
    updateWakeLockIndicator(false);
}

// Reacquire wake lock when page becomes visible again (only if there are users)
document.addEventListener('visibilitychange', async () => {
    if (document.visibilityState === 'visible') {
        if (wakeLockMethod === null && window.shouldKeepScreenAwake) {
            console.log('[Wake Lock] Page visible again, reacquiring...');
            await requestWakeLock();
        }
    }
});

// Handle page unload
window.addEventListener('beforeunload', () => {
    releaseWakeLock();
});

// Initialize indicator when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', createWakeLockIndicator);
} else {
    createWakeLockIndicator();
}

// Export functions for use in voice.js
window.requestWakeLock = requestWakeLock;
window.releaseWakeLock = releaseWakeLock;

console.log('[Wake Lock] Module ready');