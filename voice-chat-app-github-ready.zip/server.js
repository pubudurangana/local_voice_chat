﻿const express = require('express');
const https = require('https');
const fs = require('fs');
const socketIO = require('socket.io');
const path = require('path');

const app = express();
const PORT = 3001;

// HTTPS Configuration
const httpsOptions = {
  key: fs.readFileSync(path.join(__dirname, 'ssl', 'key.pem')),
  cert: fs.readFileSync(path.join(__dirname, 'ssl', 'cert.pem'))
};

// Create HTTPS server
const server = https.createServer(httpsOptions, app);

const io = socketIO(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  },
  pingTimeout: 60000,
  pingInterval: 25000
});

// Serve static files
app.use(express.static('public'));

// Room management
let rooms = {
  main: {
    name: "Main Room",
    users: [],
    private: false
  }
};

const users = new Map(); // socketId -> {username, room}

// Get local IP address
function getLocalIP() {
  const os = require('os');
  const interfaces = os.networkInterfaces();
  for (const devName in interfaces) {
    const iface = interfaces[devName];
    for (let i = 0; i < iface.length; i++) {
      const alias = iface[i];
      if (alias.family === 'IPv4' && !alias.internal) {
        return alias.address;
      }
    }
  }
  return 'localhost';
}

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log('✅ New connection:', socket.id);

  // Client sends 'join' event with username
  socket.on('join', (data) => {
    const { username } = data;
    const room = 'main'; // Default room
    
    // Store user info
    users.set(socket.id, { username, room });
    socket.join(room);
    
    console.log(`👤 User ${username} (${socket.id}) joined room: ${room}`);
    
    // Get all users in the room
    const roomUsers = Array.from(users.entries())
      .filter(([_, user]) => user.room === room)
      .map(([id, user]) => user.username);
    
    // Send to the joining user
    socket.emit('joined', {
      roomId: room,
      roomName: 'Main Room',
      users: roomUsers
    });
    
    // Broadcast to others in room
    socket.to(room).emit('roomUsers', {
      roomId: room,
      users: roomUsers
    });
    
    // Notify others about new peer
    socket.to(room).emit('new-peer', { username });
  });

  // WebRTC signaling
  socket.on('offer', (data) => {
    const { to, from, offer } = data;
    const targetSocket = Array.from(users.entries()).find(([_, user]) => user.username === to);
    
    if (targetSocket) {
      io.to(targetSocket[0]).emit('offer', { from, offer });
      console.log(`📡 Offer: ${from} → ${to}`);
    }
  });

  socket.on('answer', (data) => {
    const { to, from, answer } = data;
    const targetSocket = Array.from(users.entries()).find(([_, user]) => user.username === to);
    
    if (targetSocket) {
      io.to(targetSocket[0]).emit('answer', { from, answer });
      console.log(`📡 Answer: ${from} → ${to}`);
    }
  });

  socket.on('ice-candidate', (data) => {
    const { to, from, candidate } = data;
    const targetSocket = Array.from(users.entries()).find(([_, user]) => user.username === to);
    
    if (targetSocket) {
      io.to(targetSocket[0]).emit('ice-candidate', { from, candidate });
      console.log(`🧊 ICE: ${from} → ${to}`);
    }
  });

  // Mute status
  socket.on('mute-status', (data) => {
    const user = users.get(socket.id);
    if (user) {
      socket.to(user.room).emit('user-muted', {
        username: user.username,
        muted: data.muted
      });
    }
  });

  // Private room creation
  socket.on('create-private-room', (data) => {
    const { participants } = data;
    const creator = users.get(socket.id);
    
    if (!creator) return;
    
    const roomId = 'room-' + Date.now();
    const roomName = `${creator.username}'s Room`;
    
    rooms[roomId] = {
      name: roomName,
      users: [creator.username, ...participants],
      private: true
    };
    
    console.log(`🚪 Private room created: ${roomId} by ${creator.username}`);
    
    // Invite participants
    participants.forEach(username => {
      const targetSocket = Array.from(users.entries()).find(([_, user]) => user.username === username);
      if (targetSocket) {
        io.to(targetSocket[0]).emit('room-invite', {
          roomId,
          roomName,
          invitedBy: creator.username
        });
      }
    });
    
    socket.emit('room-created', { roomId, roomName });
  });

  // Join private room
  socket.on('join-private-room', (data) => {
    const { roomId } = data;
    const user = users.get(socket.id);
    
    if (!user || !rooms[roomId]) return;
    
    // Leave current room
    socket.leave(user.room);
    
    // Join new room
    user.room = roomId;
    socket.join(roomId);
    
    console.log(`👤 User ${user.username} joined private room: ${roomId}`);
    
    // Get users in new room
    const roomUsers = Array.from(users.entries())
      .filter(([_, u]) => u.room === roomId)
      .map(([id, u]) => u.username);
    
    socket.emit('joined', {
      roomId,
      roomName: rooms[roomId].name,
      users: roomUsers
    });
    
    socket.to(roomId).emit('roomUsers', {
      roomId,
      users: roomUsers
    });
    
    socket.to(roomId).emit('new-peer', { username: user.username });
  });

  // Leave room (back to main)
  socket.on('leave-room', () => {
    const user = users.get(socket.id);
    if (!user) return;
    
    const oldRoom = user.room;
    socket.leave(oldRoom);
    
    // Join main room
    user.room = 'main';
    socket.join('main');
    
    console.log(`👤 User ${user.username} returned to main room`);
    
    // Update old room
    const oldRoomUsers = Array.from(users.entries())
      .filter(([_, u]) => u.room === oldRoom)
      .map(([id, u]) => u.username);
    
    socket.to(oldRoom).emit('roomUsers', {
      roomId: oldRoom,
      users: oldRoomUsers
    });
    
    // Update main room
    const mainRoomUsers = Array.from(users.entries())
      .filter(([_, u]) => u.room === 'main')
      .map(([id, u]) => u.username);
    
    socket.emit('joined', {
      roomId: 'main',
      roomName: 'Main Room',
      users: mainRoomUsers
    });
    
    socket.to('main').emit('roomUsers', {
      roomId: 'main',
      users: mainRoomUsers
    });
    
    socket.to('main').emit('new-peer', { username: user.username });
  });

  // Chat Message
  socket.on('chat-message', (data) => {
    const user = users.get(socket.id);
    if (user) {
      const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      io.to(user.room).emit('chat-message', {
        username: user.username,
        text: data.text,
        time: timestamp,
        isSystem: false
      });
    }
  });

  socket.on('disconnect', () => {
    const user = users.get(socket.id);
    
    if (user) {
      console.log(`❌ User ${user.username} (${socket.id}) disconnected`);
      
      // Get remaining users in room
      users.delete(socket.id);
      
      const roomUsers = Array.from(users.entries())
        .filter(([_, u]) => u.room === user.room)
        .map(([id, u]) => u.username);
      
      // Notify others in the room
      socket.to(user.room).emit('roomUsers', {
        roomId: user.room,
        users: roomUsers
      });
    } else {
      console.log(`❌ Connection ${socket.id} disconnected`);
    }
  });
});

// Start server
server.listen(PORT, '0.0.0.0', () => {
  const localIP = getLocalIP();
  console.log('\n' + '='.repeat(60));
  console.log('🔒 HTTPS Voice Chat Server is running!');
  console.log('='.repeat(60));
  console.log(`\n📍 Access URLs:`);
  console.log(`   Local:        https://localhost:${PORT}`);
  console.log(`   Network:      https://${localIP}:${PORT}`);
  console.log(`\n📱 For mobile devices:`);
  console.log(`   iOS/Android:  https://${localIP}:${PORT}`);
  console.log(`\n⚠️  IMPORTANT:`);
  console.log(`   - Using self-signed certificate`);
  console.log(`   - Accept browser security warning to proceed`);
  console.log(`   - On mobile: Click "Advanced" → "Proceed to ${localIP}"`);
  console.log('\n' + '='.repeat(60) + '\n');
});
